# Changelog

## 6.0.0

**Migration Guide**

- Update all files

**Implemented New Features and Enhancements:**

- Remastered Ultima Layout

## 5.0.0

**Migration Guide**

- Update layout.js and layout css files
- Update theme scss files
- Replace theme jar with new jar
- Update primeflex.min.css file
- Update invoice page
- Update all widgets on pages due to PrimeFlex 3.x

**Implemented New Features and Enhancements:**

- Update PrimeFlex to 3.x
- Theme designer enhancements included

## 4.1.0

**Migration Guide**

- Update layout.js and layout css files
- Replace theme jar with new jar

**Implemented New Features and Enhancements:**

- Add support for PrimeFaces 11 with jakarta
- Update PrimeIcons to 5.0.0
- Theme designer enhancements included

## 4.0.0

**Migration Guide**

- Update layout.js and layout css files
- Replace layout files with new files
- Replace theme jar with new jar

**Implemented New Features and Enhancements:**

- Add support for PrimeFaces 11
- New demos added
- Theme designer enhancements included

## 3.0.0

**Migration Guide**

- Update layout.js file
- Replace layout files with new files
- Replace theme jar with new jar

**Implemented New Features and Enhancements:**

- Add support for Primefaces X
- New demos added
- New material theme
- Theme designer included
- Primeflex updated
- Primeicons updated

**Fixed bugs:**

- Minor fixes

## 2.1.1

**Migration Guide**

- Update layout.js and layout css files
- Replace theme jar with new jar

## 2.1.0

**Migration Guide**

- Added configurator panel
- Update layout.js and layout css files.
- Replace theme jar with new jar

## 2.0.2

**Migration Guide**

- Update layout css files

## 2.0.1

**Migration Guide**

- Added sample invoice, help and payment wizard pages.

## 2.0.0

**Migration Guide**

- Update UltimaMenu*.java file
- Replace theme jar with new jar

## 1.1.6

**Migration Guide**

- Update layout.js, UltimaMenu*.java and layout css files
- Replace theme jar with new jar

## 1.1.5

**Migration Guide**

- Update layout.js, UltimaMenu*.java and taglib files
- Replace theme jar with new jar

## 1.1.4

**Migration Guide**

- Update layout.js and layout css files
- Replace theme jar with new jar

## 1.1.3

**Migration Guide**

- Update layout.js and layout css files
- Replace theme jar with new jar

## 1.1.2

**Migration Guide**

- Update layout.js and layout css files
- Replace theme jar with new jar

## 1.1.1

**Migration Guide**

- Update layout.js and layout css files
- Replace theme jar with new jar

## 1.0.9

**Migration Guide**

- Update layout css files
- Replace theme jar with new jar

## 1.0.8

**Migration Guide**

- Update layout.js and layout css files
- Replace theme jar with new jar

## 1.0.7

**Migration Guide**

- Update theme jar, layout css files and layout.js. (<a href="https://github.com/primefaces/ultima/issues?q=is%3Aissue+is%3Aclosed+milestone%3A1.0.7">Full Changelog</a>)

## 1.0.6

**Migration Guide**

- Update theme jar and layout.js.

## 1.0.5

**Migration Guide**

- Update theme jar, layout-{color}.css and layout.js.

## 1.0.4

**Migration Guide**

- Update theme jar and layout.js

## 1.0.3

**Migration Guide**

- Update theme jar

## 1.0.2

**Migration Guide**

- Update theme jar

## 1.0.1

**Migration Guide**

- Update layout-*.css files
- Update theme jar

