## Ultima PrimeFaces

#### Getting Started

First of all, you'd need SASS to compile CSS, proceed to [SASS Installation](https://sass-lang.com/install) before beginning if you do not have SASS available in your command line.
Demo project has an integrated jetty plugin so running the sample is easy as building the css first followed by the ``mvn jetty:run`` command.

```
sass --update src/main/webapp/resources:src/main/webapp/resources --no-source-map
mvn clean jetty:run
```    

<sup>\*Note: The sass command above is supported by **Dart Sass**. Please use [Dart Sass](https://sass-lang.com/install) instead of [Ruby Sass](https://sass-lang.com/ruby-sass). </sup>
  
Navigate to http://localhost:8080/ultima to view the demos which is exactly same as the live version.

#### Migration Guide

Every change is included in **CHANGELOG.md** file at the root folder of the distribution along with the instructions to update.

#### Support

See [Ultima PrimeFaces Forum](https://forum.primefaces.org/viewforum.php?f=42) to get support about this layout.

#### License

See [Layout License](https://www.primefaces.org/layouts/licenses).
